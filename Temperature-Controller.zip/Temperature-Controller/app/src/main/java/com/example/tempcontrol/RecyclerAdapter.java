package com.example.tempcontrol;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHoler> {

    private Context context;
    private List<TimeModel> hashMap;

    public RecyclerAdapter(Context context, List<TimeModel> hashMap) {
        this.context = context;
        this.hashMap = hashMap;
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHoler(LayoutInflater.from(context).inflate(R.layout.item_adapter,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHoler holder, int position) {
        long timeStamp = hashMap.get(position).getTimeStamp() * 1000;
        holder.date.setText(TimeUtils.getTimeInStringFromTimeStamp(""+timeStamp));
        holder.per.setText(hashMap.get(position).getTemp()+"C");
        holder.humid.setText(hashMap.get(position).getHumid()+ "%");
    }

    @Override
    public int getItemCount() {
        if (!hashMap.isEmpty())
            return hashMap.size();
        else return 0;
    }

    public class ViewHoler extends RecyclerView.ViewHolder{

        private TextView date,per,humid;

        public ViewHoler(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.date);
            per = itemView.findViewById(R.id.temp);
            humid = itemView.findViewById(R.id.humid);

        }
    }

}
