package com.example.tempcontrol;

public class TimeModel {

    public TimeModel(){}

    private long timeStamp,humid;
    private double temp;

    public TimeModel(long timeStamp, long humid, double temp) {
        this.timeStamp = timeStamp;
        this.humid = humid;
        this.temp = temp;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public long getHumid() {
        return humid;
    }

    public void setHumid(long humid) {
        this.humid = humid;
    }

    public double getTemp() {
        return temp;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }
}
