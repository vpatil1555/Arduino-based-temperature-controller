package com.example.tempcontrol;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import me.itangqi.waveloadingview.WaveLoadingView;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LineChart lineChart;

    private List<TimeModel> timeModelList;
    private List<String> values_points;
    private List<Entry> graphval;
    private TextView temp,humid,tempStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            recyclerView = findViewById(R.id.rv);
            lineChart = findViewById(R.id.chart);
            temp = findViewById(R.id.tempD);
            humid = findViewById(R.id.humidD);

            tempStatus = findViewById(R.id.lk);

            findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FirebaseAuth.getInstance().signOut();
                    startActivity(new Intent(MainActivity.this, Login.class));
                    finish();
                    Toast.makeText(MainActivity.this, "Logged Out!", Toast.LENGTH_SHORT).show();
                }
            });


            graphval = new ArrayList<>();
            values_points = new ArrayList<>();

            //////////////////////////LINE CHART CONFIGURATION/////////////////////////////
            loadlinegraphSettings();
            //////////////////////////////////////////////////////////////////////////////////

            FirebaseDatabase
                    .getInstance()
                    .getReference("RECORD")
                    .limitToLast(10)
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                int i = 0;
                                timeModelList = new ArrayList<>();
                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    timeModelList.add(new TimeModel(Long.parseLong(dataSnapshot.getKey()),
                                            dataSnapshot.child("HUMIDITY").getValue(Integer.class),
                                            dataSnapshot.child("TEMP").getValue(Double.class)));

                                    values_points.add(TimeUtils.getTimeInStringFromTimeStamp(dataSnapshot.getKey()));
                                    graphval.add(new Entry(i, Math.round(dataSnapshot.child("TEMP").getValue(Double.class))));
                                    i++;
                                }

                                temp.setText(""+(int) timeModelList.get((int)snapshot.getChildrenCount()-1).getTemp()+"°C");
                                humid.setText(""+(int) timeModelList.get((int)snapshot.getChildrenCount()-1).getHumid()+"%");

                                if (timeModelList.get((int)snapshot.getChildrenCount()-1).getTemp() >= 25){
                                    tempStatus.setText("CURRENTLY COOLING YOUR ENVIRONMENT...");
                                }else if (timeModelList.get((int)snapshot.getChildrenCount()-1).getTemp() <= 23){
                                    tempStatus.setText("TEMPERATURE LESS THAN THRESHOLD COOLING OFF...");
                                }else tempStatus.setText("TEMPERATURE MAINTAINED...");

                                recyclerView.setAdapter(new RecyclerAdapter(MainActivity.this, timeModelList));

                                XAxis xAxis = lineChart.getXAxis();
                                xAxis.setValueFormatter(new IndexAxisValueFormatter(values_points));

                                LineDataSet lineDataSet_steps = new LineDataSet(graphval, "Temperature trend");
                                lineDataSet_steps.setLineWidth(4f);
                                ArrayList<ILineDataSet> iLineDataSets_steps = new ArrayList<>();
                                iLineDataSets_steps.add(lineDataSet_steps);
                                LineData lineData_Steps = new LineData(iLineDataSets_steps);

                                lineData_Steps.setValueTextSize(12);
                                lineData_Steps.setValueTextColor(Color.BLACK);

                                lineChart.setData(lineData_Steps);

                            } else {
                                Toast.makeText(MainActivity.this, "No Data to display", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
        }catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    private void loadlinegraphSettings(){

        lineChart.setBorderColor(Color.WHITE);
        lineChart.getAxisLeft().setDrawGridLines(true);
        lineChart.animateXY(2000, 2000);
        lineChart.getXAxis().setDrawGridLines(false);
        lineChart.setScaleEnabled(true);
        lineChart.setPinchZoom(true);
        lineChart.setDescription(null);
        lineChart.getAxisRight().setEnabled(false);
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        //lineChart.setPadding(10,10,10,0);

        YAxis leftAxis = lineChart.getAxisLeft();
        final XAxis xAxis = lineChart.getXAxis();
        xAxis.setLabelRotationAngle(90);


        Legend legend = lineChart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(true);
        legend.setXOffset(5f);
        legend.setYEntrySpace(5f);
        legend.setTextSize(11f);
        legend.setTextColor(Color.WHITE);
        lineChart.setExtraBottomOffset(-10f);
        xAxis.setTextColor(Color.BLACK);
        leftAxis.setTextColor(Color.BLACK);
        legend.setTextColor(Color.BLACK);


    }

}