package com.example.tempcontrol;

import android.text.format.DateFormat;

import java.util.Calendar;
import java.util.Locale;

public class TimeUtils {
    public static String getTimeInStringFromTimeStamp(String timeStamp) throws NumberFormatException {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        long time;
        time = Long.parseLong(timeStamp);
        cal.setTimeInMillis(time);
        String date = DateFormat.format("EEEE, MMM dd, yyyy", cal).toString();
        return date;

    }
}
